var openPopupBtn = document.querySelector("#open-popup-btn");
var closePopupBtn = document.querySelector(".popup-close-btn");

openPopupBtn.addEventListener("click",function(){
    document.body.classList.add("popup-active");
});

closePopupBtn.addEventListener("click",function(){
    document.body.classList.remove("popup-active");
});
var openPopupBtn = document.querySelector("#page1-signin");
var closePopupBtn = document.querySelector(".popup-close-btn");

openPopupBtn.addEventListener("click",function(){
    document.body.classList.add("popup-active");
});

closePopupBtn.addEventListener("click",function(){
    document.body.classList.remove("popup-active");
});
var cardNumInput = document.querySelector('#cardNum')

cardNumInput.addEventListener('keyup', () => {
    let cNumber = cardNumInput.value
    cNumber = cNumber.replace(/\s/g, "")

    if(Number(cNumber)){
        cNumber = cNumber.match(/.{1,4}/g)
        cNumber = cNumber.join(" ")
        cardNumInput.value = cNumber
    }
})

